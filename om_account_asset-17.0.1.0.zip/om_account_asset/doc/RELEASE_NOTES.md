## Module <om_account_asset>

#### 15.11.2023
#### Version 17.0.1.0
##### ADD
- initial release
