## Module hr_reminder

#### 06.11.2020
#### Version 15.0.1.0.0
##### ADD
- Initial commit for OpenHrms Project

#### 26.07.2022
#### Version 15.0.1.1.0
##### UPDATE
- Change the PO file